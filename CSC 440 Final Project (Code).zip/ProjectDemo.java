
/**
 * Write a description of class ProjectDemo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ProjectDemo
{
    public static void main(String[] args) {
       //create login window object
       LoginWindow gui = new LoginWindow();
       gui.setVisible(true);
    }
}
